import boto3
import json
from decimal import Decimal

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')

    # Beispiel-Datensätze
    kunde_data = [
    {
        "ID-Kunde": 1,
        "Email": "Hubert1@gmail.com",
        "Vorname": "Hubert",
        "Nachname": "Pouros",
        "Telefon": "+1 (301) 564-2414",
        "Adresse": "7547 Schamberger Parkway"
    },
    {
        "ID-Kunde": 2,
        "Email": "Delbert_Prosacco@gmail.com",
        "Vorname": "Delbert",
        "Nachname": "Prosacco",
        "Telefon": "+1 (406) 939-0582",
        "Adresse": "2030 Stacey Via"
    },
    {
        "ID-Kunde": 3,
        "Email": "Craig79@hotmail.com",
        "Vorname": "Craig",
        "Nachname": "Oberbrunner",
        "Telefon": "+1 (037) 657-3236",
        "Adresse": "209 Freddie Plain"
    },
    {
        "ID-Kunde": 4,
        "Email": "Norman.Farrell-Bode21@gmail.com",
        "Vorname": "Norman",
        "Nachname": "Farrell-Bode",
        "Telefon": "+1 (036) 143-3159",
        "Adresse": "66273 Nicolas Ridge"
    },
    {
        "ID-Kunde": 5,
        "Email": "Harold7@hotmail.com",
        "Vorname": "Harold",
        "Nachname": "Ratke",
        "Telefon": "+1 (932) 455-2312",
        "Adresse": "807 Alexys Keys"
    }]

    mitarbeiter_data = [{"ID-Mitarbeiter": 1, "Name": "Mitarbeiter 1"}, {"ID-Mitarbeiter": 2, "Name": "Mitarbeiter 2"}]
    lager_data = [{
        "ID-Lager": 1,
        "name": "wartung_verschleiss",
        "beschreibung": "Wartung & Verschleiß 4 jahre",
        "S3-bild-url": "https://lego-defender-model-auto.s3.eu-central-1.amazonaws.com/bilder/landrover_web_rundum/landrover_vbs.jpg",
        "anzahl": 0,
        "farbe": "",
        "preis": 8000.00,
        "kommentar": "ServiceProdukte"
    }]
    auftrag_data = [{"ID-Auftrag": 1, "Produkt": "Produkt 1"}, {"ID-Auftrag": 2, "Produkt": "Produkt 2"}]
    fertigungsliste_data = [{"ID-Fertigungsliste": 1, "Produktionsnummer": "123"}, {"ID-Fertigungsliste": 2, "Produktionsnummer": "456"}]

    # Funktion zum Einfügen von Datensätzen
    def insert_data(table, data):
        for item in data:
            table.put_item(Item=item)

    # Tabellen-Objekte
    kunde_table = dynamodb.Table('Kunde')
    mitarbeiter_table = dynamodb.Table('Mitarbeiter')
    lager_table = dynamodb.Table('Lager')
    auftrag_table = dynamodb.Table('Auftrag')
    fertigungsliste_table = dynamodb.Table('Fertigungsliste')

    # Einfügen der Datensätze
    insert_data(kunde_table, kunde_data)
    insert_data(mitarbeiter_table, mitarbeiter_data)
    insert_data(lager_table, lager_data)
    insert_data(auftrag_table, auftrag_data)
    insert_data(fertigungsliste_table, fertigungsliste_data)

    return {
        'statusCode': 200,
        'body': json.dumps('Datensätze erfolgreich hinzugefügt!')
    }
